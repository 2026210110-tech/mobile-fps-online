Mobile FPS v33
v29 + v30/v32 統合・オンライン完全版

実装項目:
1. ルームID作成
2. ルームIDで参加
3. 他プレイヤーの位置・名前・スキン同期
4. オンライン接続表示
5. WebSocket通信
6. Cloudflare Workers対応
7. Durable Objectsでルーム状態を管理
8. 建物・建物内移動
9. 広い500×500の3Dパースマップ
10. 固定BOT（全員同サイズ・移動なし）
11. 武器切り替え・射撃・リロード
12. 「村川」設定：広い自動照準 + 999999ダメージ
13. ロビー復帰
14. スマホ/iPad操作
15. 画像スキン（banana / fox）
16. 建築（壁・床・坂）
17. ダッシュ・スライド・一人称/三人称・照準
18. 壁の裏側のBOTを遮蔽する簡易レイキャスト

Cloudflare公開について:
この版は Worker + Durable Object が必要です。
「静的ファイルをアップロード」だけではWebSocket (/ws) が動きません。

PC/Mac:
1. ZIPを解凍
2. npm install
3. npx wrangler login
4. npx wrangler deploy
5. 表示された https://xxxx.workers.dev/ を開く

2台で遊ぶ:
1. 1台目：名前を入力 → 「ルームを作る」
2. 表示されたルームIDを2台目へ共有
3. 2台目：名前 + 同じルームID → 「ルームに参加」
4. 両方で「プレイ」

Cloudflareの静的アップロード画面に
「静的アセットのみ」「Wranglerを使用してください」
と出ている場合は、その画面ではなくWranglerでデプロイしてください。
